
#ifndef __TEST_LOCAL_IRQ__
#define __TEST_LOCAL_IRQ__

#ifdef __cplusplus
extern "C"
{
#endif


void command_TestLocalIrq(void);


#ifdef __cplusplus
}
#endif 

#endif

