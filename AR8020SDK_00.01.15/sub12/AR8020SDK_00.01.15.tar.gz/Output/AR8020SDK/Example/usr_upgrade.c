#include "usr_upgrade.h"

int Upgrade_Data_Handler(char *buf,int len,char *ret)
{
    ret[0] = 1;
    ret[1] = 2;
    ret[2] = 3;
    
    return 0;

}


//��������
 
