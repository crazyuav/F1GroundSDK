#ifndef __TEST_NET_REPEATER_SKY_H__
#define __TEST_NET_REPEATER_SKY_H__

#ifdef __cplusplus
extern "C"
{
#endif


void command_TestNetRepeaterSky( void );


#ifdef __cplusplus
}
#endif 

#endif

