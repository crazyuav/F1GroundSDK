#ifndef TEST_FLOAT_H
#define TEST_FLOAT_H

#ifdef __cplusplus
extern "C"
{
#endif


void test_float_calculate_pi(void);


#ifdef __cplusplus
}
#endif

#endif

