#ifndef _TEST_HAL_TIM_
#define _TEST_HAL_TIM_

#ifdef __cplusplus
extern "C"
{
#endif


void commandhal_TestTim(uint8_t *pu8_timerNum, uint8_t *pu8_timerCount);
void commandhal_TestTimAll(void);


#ifdef __cplusplus
}
#endif 

#endif
