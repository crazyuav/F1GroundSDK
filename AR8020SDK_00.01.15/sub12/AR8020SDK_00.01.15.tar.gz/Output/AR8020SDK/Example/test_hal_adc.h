#ifndef __TEST_HAL_ADC_H__
#define __TEST_HAL_ADC_H__

#ifdef __cplusplus
extern "C"
{
#endif


void command_TestHalAdRead(unsigned char *ch, unsigned char *nch);


#ifdef __cplusplus
}
#endif 

#endif
