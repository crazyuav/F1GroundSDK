#ifndef __TEST_DHCP_H__
#define __TEST_DHCP_H__

#ifdef __cplusplus
extern "C"
{
#endif


void command_TestDhcp( void );



#ifdef __cplusplus
}
#endif 

#endif


