#ifndef __TEST_TCP_ECHO_H__
#define __TEST_TCP_ECHO_H__

#ifdef __cplusplus
extern "C"
{
#endif


void command_TestTcpEcho( void );


#ifdef __cplusplus
}
#endif 

#endif

