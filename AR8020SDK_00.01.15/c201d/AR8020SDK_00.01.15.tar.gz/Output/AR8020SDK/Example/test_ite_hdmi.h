#ifndef __TEST_HDMI_H__
#define __TEST_HDMI_H__

#ifdef __cplusplus
extern "C"
{
#endif


void command_hdmiHandler(uint8_t *index);


#ifdef __cplusplus
}
#endif

#endif

