#ifndef TEST_MEMORY_H
#define TEST_MEMORY_H

#ifdef __cplusplus
extern "C"
{
#endif

void command_TestMemory(char * cpu, char * totalNum, char * len);
void command_TestItcmMemory(char * cpu, char * totalNum, char * len);


#ifdef __cplusplus
}
#endif 

#endif
