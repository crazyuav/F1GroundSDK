#ifndef _TEST_OS_SIGNAL_H
#define _TEST_OS_SIGNAL_H

#ifdef __cplusplus
extern "C"
{
#endif


void test_os_signal(void);


#ifdef __cplusplus
}
#endif 

#endif
