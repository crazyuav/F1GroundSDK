#ifndef _TEST_NET_H
#define _TEST_NET_H

void command_test_net(char* arg1);

#endif
