#ifndef __TEST_UDP_ECHO_H__
#define __TEST_UDP_ECHO_H__

#ifdef __cplusplus
extern "C"
{
#endif


void command_TestUdpEcho( void );


#ifdef __cplusplus
}
#endif 

#endif

