#ifndef __TEST__FUNC__H
#define __TEST__FUNC__H

#ifdef __cplusplus
extern "C"
{
#endif


void command_TestTask(char* arg1);
void command_TestTaskQuit(void);


#ifdef __cplusplus
}
#endif 

#endif
