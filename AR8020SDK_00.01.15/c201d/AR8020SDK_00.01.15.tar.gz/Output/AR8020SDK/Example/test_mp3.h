#ifndef __TEST__MP3_ENCODER__H
#define __TEST__MP3_ENCODER__H

#ifdef __cplusplus
extern "C"
{
#endif


uint32_t command_TestMP3Encoder(char* uc_option);


#ifdef __cplusplus
}
#endif

#endif
