#ifndef __TEST_PING_H__
#define __TEST_PING_H__

#ifdef __cplusplus
extern "C"
{
#endif


void command_TestPing( void );



#ifdef __cplusplus
}
#endif 

#endif



