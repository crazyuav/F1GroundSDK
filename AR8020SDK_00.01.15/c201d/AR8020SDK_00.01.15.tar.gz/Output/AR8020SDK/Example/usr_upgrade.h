#ifndef __USR_UPGRADE__
#define __USR_UPGRADE__


#ifdef __cplusplus
extern "C"
{
#endif

    int Upgrade_Data_Handler(char *buf,int len,char *ret);
    
#ifdef __cplusplus
}
#endif

#endif
