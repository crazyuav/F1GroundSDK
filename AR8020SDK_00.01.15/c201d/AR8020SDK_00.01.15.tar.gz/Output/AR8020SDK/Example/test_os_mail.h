#ifndef _TEST_OS_MAIL_H
#define _TEST_OS_MAIL_H

#ifdef __cplusplus
extern "C"
{
#endif


void test_os_mail(void);


#ifdef __cplusplus
}
#endif

#endif
